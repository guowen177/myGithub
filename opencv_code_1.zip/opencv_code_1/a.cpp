#include <stdio.h>
#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char** argv )
{
   Mat image;
    image = imread( "./1.png", 1 );
    if ( !image.data )
    {
        printf("No image data \n");
        return -1;
    }
    namedWindow("Display Image", WINDOW_AUTOSIZE );
    imshow("Display Image", image);
    
    Mat a=Mat::zeros(image.size(),CV_8UC3);
    cvtColor(image,a,COLOR_BGR2HSV);
   
    namedWindow("play Image", WINDOW_AUTOSIZE );
    imshow("play Image", a);

    waitKey(0);
    return 0;
}


